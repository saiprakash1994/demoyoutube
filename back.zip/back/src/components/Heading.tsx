import React from "react";

interface HeadingProps {
    children:string
}
export const Heading = ({children}:HeadingProps) => {
    return <div>
      {children}
  </div>;
};
