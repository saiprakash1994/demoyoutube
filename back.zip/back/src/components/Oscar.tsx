import React from 'react'
// interface OscarProps{
// children:React.ReactNode
// }
export const Oscar = (props: { children: React.ReactNode }) => {
  return <div>{props.children}</div>;
};

