import React from 'react'
interface personprops{
    name:{
        first:string,
        last:String
    }[]
}
export const PersonList = ({name}:personprops) => {
  return (
    <div>
      {name.map((e)=>(
        <div>
          <h1>{e.first}</h1>
          <h1>{e.last}</h1>

        </div>
      ))}
    </div>
  )
}

