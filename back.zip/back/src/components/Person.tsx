import React from "react";
interface nameProps {
  name: {
    first: string;
    last: string;
  };
}
export const Person = ({ name }: nameProps) => {
  return (
    <div>
      {" "}
      {name.first}
      {name.last}
    </div>
  );
};
