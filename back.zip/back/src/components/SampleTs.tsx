import React from "react";
interface aProps {
  name: string;
  count: number;
  isLoggedIn: boolean;
}
export const SampleTs = ({ name, count, isLoggedIn }: aProps) => {
  return (
    <div>
      <h1>{count}</h1>
      <h1>{name}</h1>
      <h1>{isLoggedIn}</h1>
    </div>
  );
};
