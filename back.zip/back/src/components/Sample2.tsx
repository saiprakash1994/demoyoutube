interface sample2Props{
    name: string,
    age:number,
}
export const Sample2 = () => {
    
}