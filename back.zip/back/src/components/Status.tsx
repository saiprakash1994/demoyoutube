import React from 'react'
interface statusProps{ 
  //uion of string literals
  status: "loading"|"success"|"error"
  message:string
}
export const Status = ({status}:statusProps) => {
    let message
    if((status||message) == "loading"){
        message='loading..'
    }else if ((status || message) == "success") {
      message = "Data fetched successfully";
    } else if ((status || message) == "error") {
      message = "error fetching data";
    }
  return (
    <div>
      <h1>status --{message}</h1>
     
    </div>
  )
}




