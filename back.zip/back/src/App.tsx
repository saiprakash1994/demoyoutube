import React,{useState} from 'react';
import './App.css';
import {SampleTs}  from './components/SampleTs';
import {Person} from './components/Person';
import {PersonList} from './components/PersonList';
import { Status } from './components/Status';
import { Heading } from './components/Heading';
import { Oscar } from './components/Oscar';
import ReactPlayer from 'react-player'

function App() {
  const [url, setUrl] = useState()
 
  const personName={
    first:"sai",
    last:"prakash"
  }
  const personList=[{
    first:"sai",
    last:"prakash"
  },{
    first:"sai1",
    last:"prakash1"
  },{
    first:"sai2",
    last:"prakash2"
  }]
  return (
    <div className="App">
      <SampleTs name={"sai"} count={10} isLoggedIn={true} />
      <Person name={personName}></Person>
      <PersonList name={personList}></PersonList>
      <Status status={"error"} message={"loaing"}></Status>
      <Heading>Placeholder text</Heading>
       <Oscar>
        <Heading>onpassive
        </Heading>
      </Oscar>
      <input placeholder='url' onChange={(e:any)=>{setUrl(e.target.value)}}></input>
      <iframe src={url}></iframe>
      <ReactPlayer
        url={url}
        
  config={{
    youtube: {
      playerVars: {

        preload: "auto",

        autoplay: true,

    }
    },
    
  }}
/>
    </div>
  );
}

export default App;
